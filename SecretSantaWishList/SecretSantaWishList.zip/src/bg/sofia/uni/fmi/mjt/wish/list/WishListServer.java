package bg.sofia.uni.fmi.mjt.wish.list;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Iterator;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class WishListServer {
    private static final String SERVER_HOST = "localhost";
    private static final int BUFFER_SIZE = 1024;

    private int serverPort;
    private boolean serverState = false;
    private Map<String, ArrayList<String>> wishes = new LinkedHashMap<>();

    public WishListServer(int serverPort) {
        this.serverPort = serverPort;
    }

    public void start() {
        try (ServerSocketChannel serverSocketChannel = ServerSocketChannel.open()) {
            this.serverState = true;
            serverSocketChannel.bind(new InetSocketAddress(SERVER_HOST, this.serverPort));
            serverSocketChannel.configureBlocking(false);

            Selector selector = Selector.open();
            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);

            ByteBuffer buffer = ByteBuffer.allocateDirect(BUFFER_SIZE);

            while (serverState) {
                int readyChannels = selector.select();
                if (readyChannels == 0) {
                    continue;
                }

                Set<SelectionKey> selectedKeys = selector.selectedKeys();
                Iterator<SelectionKey> keyIterator = selectedKeys.iterator();

                while (keyIterator.hasNext() && serverState) {
                    SelectionKey key = keyIterator.next();
                    if (key.isReadable()) {
                        SocketChannel sc = (SocketChannel) key.channel();

                        buffer.clear();
                        int r = sc.read(buffer);
                        if (r <= 0) {
                            System.out.println("nothing to read, will close channel" + System.lineSeparator());
                            sc.close();
                            break;
                        }

                        buffer.flip();
                        byte[] byteArray = new byte[buffer.remaining()];
                        buffer.get(byteArray);
                        String message = new String(byteArray, "UTF-8");
                        message = message.replace(System.lineSeparator(), "");

                        String name = "";
                        String gift = "";
                        String[] words = message.split("\\s+");
                        String command = words[0];
                        if (words.length > 1) {
                            name = words[1];
                            gift = message.substring(command.length() + name.length() + 2);
                        }
                        if (command.equals("disconnect")) {
                            sc.close();
                            break;
                        }
                        if (command.toLowerCase().equals("post-wish")) {
                            if (this.wishes.containsKey(name)) {
                                if (this.wishes.get(name).contains(gift)) {
                                    buffer.flip();
                                    sc.write(ByteBuffer.wrap(("[ The same gift for student " + name +
                                            " was already submitted ]"
                                            + System.lineSeparator()).getBytes()));
                                } else {
                                    this.wishes.get(name).add(gift);
                                    buffer.flip();
                                    sc.write(ByteBuffer.wrap(("[ Gift " + gift +
                                            " for student " + name + " submitted successfully ]"
                                            + System.lineSeparator()).getBytes()));
                                }
                            } else {
                                this.wishes.put(name, new ArrayList<>(Collections.singleton(gift)));
                                buffer.flip();
                                sc.write(ByteBuffer.wrap(("[ Gift " + gift +
                                        " for student " + name + " submitted successfully ]"
                                        + System.lineSeparator()).getBytes()));
                            }
                        } else if (command.toLowerCase().equals("get-wish")) {
                            if (this.wishes.isEmpty()) {
                                buffer.flip();
                                sc.write(ByteBuffer.wrap(("[ There are no students present in the wish list ]"
                                        + System.lineSeparator())
                                        .getBytes()));
                            } else {
                                List<String> keysAsArray = new ArrayList<>(this.wishes.keySet());
                                Random random = new Random();
                                String randomName = keysAsArray.get(random.nextInt(keysAsArray.size()));
                                buffer.flip();
                                sc.write(ByteBuffer.wrap(("[ " + randomName + ": "
                                        + this.wishes.get(randomName).toString() + " ]"
                                        + System.lineSeparator()).getBytes()));
                                this.wishes.remove(randomName);
                            }
                        } else {
                            buffer.flip();
                            sc.write(ByteBuffer.wrap(("[ Unknown command ]" + System.lineSeparator()).getBytes()));
                        }

                    } else if (key.isAcceptable()) {
                        ServerSocketChannel sockChannel = (ServerSocketChannel) key.channel();
                        SocketChannel accept = sockChannel.accept();
                        accept.configureBlocking(false);
                        accept.register(selector, SelectionKey.OP_READ);
                    }
                    keyIterator.remove();
                }

            }

        } catch (IOException e) {
            System.out.println("There is a problem with the server socket" + System.lineSeparator());
            e.printStackTrace();
        }
    }

    public void stop() {
        this.serverState = false;
    }

    public static void main(String[] args) {
        WishListServer wishListServer = new WishListServer(7777);
        wishListServer.start();
    }
}
